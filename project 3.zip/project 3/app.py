import pandas as pd

def save_to_excel(roll_number, name):
    data = {
        'Roll Number': [roll_number],
        'Name': [name]
    }
    df = pd.DataFrame(data)

    # If the file doesn't exist, create it with column names
    try:
        existing_data = pd.read_excel('data.xlsx')
        df = pd.concat([existing_data, df], ignore_index=True)
    except FileNotFoundError:
        pass

    df.to_excel('data.xlsx', index=False)

if __name__ == "__main__":
    while True:
        roll_number = input("Enter Roll Number (type 'exit' to stop): ")
        if roll_number.lower() == 'exit':
            break

        name = input("Enter Name: ")
        print("Successfully!")

        save_to_excel(roll_number, name)
